<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agence extends Model
{
    //

    protected $fillable = [

    	'Code_Agence',
    	'Nom_Agence',
    	'Date_Debut',
    	'Date_Fin',
    	'Map_LocH',
    	'Map_LocV',
    	'lieu'




            ];
}
