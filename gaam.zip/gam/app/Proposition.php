<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proposition extends Model
{
    //

    protected $fillable = [

    'Proposition_id',	'Proposition_commune',	'Proposition_wilaya'
    
     



     ];
}
