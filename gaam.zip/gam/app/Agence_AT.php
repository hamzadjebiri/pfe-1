<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agence_AT extends Model
{
    //

    protected $fiallable =[


     'Nom_AgenceAT',
     'Prix_AgenceAT',
     'min_duration',
     'max_duration',
     'avis',
     'Travaux',
     'critere'



      ];
}
