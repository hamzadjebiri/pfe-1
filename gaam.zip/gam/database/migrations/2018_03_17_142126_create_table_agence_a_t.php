<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableAgenceAT extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!schema::hasTable('AgenceAT'))
          {
             Schema::create('AgenceAT' ,function (Blueprint $table)
             {
               $table->increments('id_AgenceAT');
               $table->string('Nom_AgenceAT')->unique();
               $table->double('Prix_AgenceAT');
               $table->double('min_duration');
               $table->double('max_duration');
               $table->longText('avis');
               $table->longText('critere');
               $table->longText('Travaux');
                




             });
           }  
        //
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
