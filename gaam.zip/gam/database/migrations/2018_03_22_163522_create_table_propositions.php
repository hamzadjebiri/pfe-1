<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTablePropositions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //


        if (!schema::hasTable('Proposition'))
          {
             Schema::create('Proposition' ,function (Blueprint $table)
             {

             $table->increments('Proposition_id');
             $table->string('Proposition_commune');
             $table->string('Proposition_wilaya');


             });   
        
          }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
