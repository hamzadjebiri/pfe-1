<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableAgence extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        if (!schema::hastable('agence'));
           {
              Schema::create('agence' , function(Blueprint $table )
                  {
                    $table->increments('ID_Agence');
                    $table->string('Code_Agence')->unique();
                    $table->string('Nom_Agence');
                    $table->date('Date_Debut');
                    $table->date('Date_Din');
                    $table->string('Map_LocV');
                    $table->string('Map_LocH');
                    $table->string('lieu'); 
                     


                  }); 
           } 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
